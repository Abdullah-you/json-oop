#OOP Exercise 2: Create a Vehicle class without any variables and methods
class Vehicle:
    pass
