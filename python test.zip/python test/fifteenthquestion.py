password = "1234"
def pin_check(pin):
    print(len(password) == 4 or len(password) == 6)
pin_check(password)