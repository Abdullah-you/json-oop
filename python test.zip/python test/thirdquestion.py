def shape(height):
    for i in range(1, height+1):
        print(str(i) * i)
shape(4)